const cfg = window.MADAR_CONFIG || {};
const configured = cfg.SUPABASE_URL.startsWith("https://") && !cfg.SUPABASE_URL.includes("YOUR_") && cfg.SUPABASE_ANON_KEY && !cfg.SUPABASE_ANON_KEY.includes("YOUR_");
const client = configured && window.supabase ? window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY) : null;
document.getElementById("year").textContent = new Date().getFullYear();

const form = document.getElementById("application-form");
const message = document.getElementById("form-message");
form.addEventListener("submit", async (event) => {
  event.preventDefault();
  message.textContent = "";
  if (!client) {
    message.textContent = "الموقع جاهز، لكن قاعدة البيانات لم تُربط بعد. أكمل إعداد Supabase في ملف config.js.";
    message.className = "form-message error";
    return;
  }
  const data = Object.fromEntries(new FormData(form).entries());
  const payload = {
    full_name: data.full_name.trim(),
    email: data.email.trim().toLowerCase(),
    date_of_birth: data.date_of_birth,
    phone: data.phone.trim(),
    self_introduction: data.self_introduction.trim(),
    initiative_example: data.initiative_example.trim() || null,
    weekly_availability: data.weekly_availability,
    governorate: data.governorate.trim(),
    school: data.school.trim(),
    school_year: data.school_year,
    motivation: data.motivation.trim(),
    interests: data.interests.trim()
  };
  const button = form.querySelector("button[type=submit]");
  button.disabled = true; button.textContent = "جارٍ إرسال الطلب...";
  const { error } = await client.from("applications").insert(payload);
  button.disabled = false; button.innerHTML = 'إرسال الطلب <span>←</span>';
  if (error) {
    message.textContent = "تعذر إرسال الطلب حاليًا. تأكد من الاتصال وحاول مرة أخرى.";
    message.className = "form-message error";
    console.error(error);
    return;
  }
  form.reset();
  message.textContent = "تم استلام طلبك بنجاح. شكرًا لاهتمامك بالانضمام إلى مَدار!";
  message.className = "form-message success";
});