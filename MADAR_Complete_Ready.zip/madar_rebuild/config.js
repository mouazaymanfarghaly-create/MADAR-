// إعدادات الاتصال بمشروع Supabase الخاص بمَدار.
// هذا مفتاح Publishable عام مخصص للاستخدام في واجهة الموقع.
// لا تضع هنا Secret key أو service_role key مطلقًا.
window.MADAR_CONFIG = {
  SUPABASE_URL: "https://pbgkkphblduayukyfkiq.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_27h-QnkVCV9Ma5OwiJvbbQ_OhSaTBmq"
};
